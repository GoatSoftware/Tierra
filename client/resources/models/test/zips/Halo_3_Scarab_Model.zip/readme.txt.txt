Title                : Halo 3 Scarab - Unfinished
Release Date   : 16/October/2009
Author             : Hunter/Martyn Lee Ball
Email Address   : martynball@hotmail.co.uk
Web Page        : http://martynleeball.blogspot.com
Description       : This is a 3d model of the Halo 3 Scarab. It is an old model so it may be pretty crappy. It is also unfinished so if you ar eplanning on using it then you will need to finish it off. Please give me (Hunter/Martyn Lee Ball) credit for any use of this model, even if it is modified.

Copyright / Permissions

NO WARRANTIES.  The SOFTWARE PRODUCT and any related documentation is provided �as is� without warranty of any kind, either express or implied, including, without limitation, the implied warranties or merchantability, fitness for a particular purpose, or noninfringement. The entire risk arising out of use or  performance of the SOFTWARE PRODUCT remains with you.

----------------------
Halo (c) Bungie / Microsoft all rights reserved
Halo CE (c) Gearbox Software, 101 East Park Blvd #1069, Plano, TX 75074.
All other trademarks and trade names are properties of their respective owners.